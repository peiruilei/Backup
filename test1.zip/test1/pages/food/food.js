// pages/food/food.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    siteIcon:'../../static/siteIcon2x.png',
    siteInfo:'郑州市众意西路路劲大厦1617',
    searchIcon: '../../static/search.png',
    imgUrls: ['../../static/swiper-20191012-101130.png', '../../static/swiper-20191012-101130.png','../../static/swiper-20191012-101130.png'],
    noticeIcon:'../../static/notice.png',
    noticeInfo: '用户xxx-13099999999获得返现',
    shop:[{img:'', name:'炭火烤肉（路劲大厦店）', reward:'￥26', distance:'2.1km'},
      {img: '', name: '炭火烤肉（路劲大厦店）', reward: '￥26', distance: '2.1km'},
      {img: '', name: '炭火烤肉（路劲大厦店）', reward: '￥26', distance: '2.1km'},
      {img: '', name: '炭火烤肉（路劲大厦店）', reward: '￥26', distance: '2.1km'},
      {img: '', name: '炭火烤肉（路劲大厦店）', reward: '￥26', distance: '2.1km'}],
    siteIconMin: '../../static/siteIcon.png'
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})