// pages/shippingAddress/shippingAddress.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    shippingAddress:[{detail:'众意西路路劲大厦1617', name:'赵乐', phone:'130 3376 0661', font:'公司'},
      { detail: '众意西路路劲大厦1617', name: '赵乐', phone: '130 3376 0661', font: '家'},
      { detail: '众意西路路劲大厦1617', name: '赵乐', phone: '130 3376 0661', font: '学校'}],
    arrow:'../../static/arrow.png',
    addIcon:'../../static/add.png'
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})