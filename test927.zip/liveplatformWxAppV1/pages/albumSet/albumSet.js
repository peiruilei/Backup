// pages/albumSet/albumSet.js
import *as Api from '../../http/api.js'
Page({
  data: {
    selectId:0,//选项卡
    albumSetId: '', //相册集ID
    introduce:{},//相册集介绍
    pageNum:1,//页码
    albumArr:[],//相册集列表数组
    bottomMessage:"数据加载中...",//到达底部加载更多提示
    pageSize:10,     //相册个数
    bannerImg: '',  //顶部banner图片
    shareInfo: {}  //分享配置
  },
  //选项卡切换
  choose: function(e){
    this.setData({
      selectId:e.currentTarget.dataset.sid
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      albumSetId: options.albumSetId
    })
    this.getAlbumIntroduce()
    this.getAlbumList()
    this.getShareInfo()
    this.getBannerImg()
    
  },
  //获取相册集介绍
  getAlbumIntroduce:function(){
    Api.albumSetIntroduction({ photoSetId: this.data.albumSetId})
      .then(res => {
        this.setData({ introduceObj: res.result })
        wx.setNavigationBarTitle({ title: res.result.activityTime })
      })
  },
  //获取相册集列表
  getAlbumList:function(){
    let data = {
      photoSetId: this.data.albumSetId,
      pageNum: this.data.pageNum,
      pageSize: this.data.pageSize
    };
    Api.albumSetList(data).then(res => {
      this.setData({ 
        albumArr: this.data.albumArr.concat(res.result.list) ,
        pageNum: this.data.pageNum+1
      })
      if (this.data.albumArr.length == res.result.total) {
        this.setData({ bottomMessage: "-没有更多内容了-" })
      }
    })
  },
  //跳转到启动页
  toLaunch: function(e){
    wx.reLaunch({
      url: `/pages/album/albumLaunch/albumLaunch?scene=${e.currentTarget.dataset.id}`
    })
  },
  //获取分享配置
  getShareInfo: function(){
    Api.albumSetShare({
      photoSetId: this.data.albumSetId
    }).then(res => {
        this.setData({ shareInfo: res.result })
      })
  },
  //获取banner图片
  getBannerImg: function(){
    Api.albumSetBannerImg({ albumSetId: this.data.albumSetId })
      .then(res => {
        this.setData({ bannerImg: res.result })
      })
  },
  // 分享
  onShareAppMessage: function(){
    return{
      title: this.data.shareInfo.title,
      path: `/pages/albumSet/albumSet?albumSetId=${this.data.albumSetId}`,
      imageUrl: this.data.shareInfo.shareCover
    }
  },
  // 加载更多
  onReachBottom: function () {
    if (!this.data.selectId) this.getAlbumList()
  }
})