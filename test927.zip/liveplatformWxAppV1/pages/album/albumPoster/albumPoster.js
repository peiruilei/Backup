// pages/album/albumPoster/albumPoster.js
var cardImgList = ['https://picture-live.oss-cn-beijing.aliyuncs.com/default_diagram/wechat/poster_background.png'];
import { savePhoto,accessPhoto,transferAuth,downImg } from '../../../utils/util.js'
Page({
  data: {
    src: '',
    bg: '',
    title: ''
  },
  onLoad: function (option){
	let wxCardImg = JSON.parse(option.wxCard)
    cardImgList.push(...wxCardImg)
    this.setData({
      src: wxCardImg[0],
      title: option.title
    })
    this.createPoster()
    wx.showLoading({
      title: '加载中...',
      mask: true
    })
    setTimeout(()=>{
      wx.hideLoading()
    },2000)
  },
	//用户保存海报
  savePoster: function(e){
    this.createPoster();
    let imgPath = '';
    this.producedPoster()
      .then(res => {
        imgPath = res
        return accessPhoto()
      }).then(res => { 
        // this.savePhoto(imgPath)
      }).catch(err => { 
        return transferAuth()
      }).then(res => {  
        savePhoto(imgPath)
      })
  },
  // 生成图片
  producedPoster: function (){
    return new Promise((resolve,reject) => {
      wx.canvasToTempFilePath({
        canvasId: 'myCanvas',
        quality: 1,
        success: res => {
          res.tempFilePath ? resolve(res.tempFilePath) : reject(false)
        },
        fail: eorr => {
          reject(false);
          wx.showToast({ title: '生成图片失败,稍后尝试!', icon: 'none' })
        }
      })
    })
  },
  //创建样式
  createPoster: async function () {
    let imgList = [];
    for (let i = 0; i < cardImgList.length; i++){
      await downImg(cardImgList[i]).then(res => {
        imgList.push(res)
      });
    }
    const ctx = wx.createCanvasContext('myCanvas');
    ctx.fillRect(0, 0, 375, 375)
    ctx.drawImage(imgList[0], 0, 0, 375, 375);
    ctx.font = `16px bold`;
    ctx.setFillStyle('#151515')
    ctx.textAlign = 'center';
    ctx.fillText(this.data.title, 187.5, 40.5);
    ctx.drawImage(imgList[1], 97, 78, 180, 180);
    ctx.font = `15px normal`;
    ctx.setFillStyle('#151515')
    ctx.fillText('长按图片', 187.5, 300);
    ctx.setFillStyle('#151515')
    ctx.fillText('识别小程序后立即查看', 187.5, 320);
    ctx.draw()
    cardImgList = ['https://picture-live.oss-cn-beijing.aliyuncs.com/default_diagram/wechat/poster_background.png'];
  }
})