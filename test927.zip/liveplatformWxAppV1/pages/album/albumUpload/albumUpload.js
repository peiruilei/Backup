// pages/album/albumUpload/albumUpload.js
import { uploadImg } from '../../../utils/util.js'
Page({
  data: {
	albumClassId: '', //相册分类ID
	albumId: ''		,//相册ID
	files: []        ,//上传的文件
	width: 0,
	mask: false		,//显示遮罩层?
	carryOut: false  ,//完成
	count:0,
	userId: ''     ,//用户ID
  successCount: 0, //成功的数量
  failCount: 0   	//失败的数量
  },

  /**
   * 生命周期函数--监听页面加载
   */
    onLoad: function (options) {
  	    this.setData({
  	    	albumClassId: options.albumClassId,
  	    	albumId: options.albumId,
  	    	userId: wx.getStorageSync('userInfo').uid
  	    })
    },
	//选择图片
	chooseImage: async function(){
		if(this.data.files.length >=9){
			wx.showToast({
			  title: '一次性最多上传9张',
			  icon: 'none',
			  duration: 2000
			})
			return
		}
		wx.chooseImage({
			count: 9-this.data.files.length,
			success: (res) => {
				this.setData({
					files: this.data.files.concat(res.tempFilePaths)
				})
			}
		})
	},
	// 删除图片列表
	deleteImg: function(e){
		let fileIndex = [];
		this.data.files.map((item,index) => {
			if(item == e.currentTarget.dataset.item){
				this.data.files.splice(index,1)
				this.setData({
					files: this.data.files
				})
				return 
			}
		})
	},
	// 点击上传
	upload: function(){
		if(!this.data.files.length){
			wx.showToast({
			  title: '请添加图片',
			  icon: 'none',
			  duration: 2000
			})
			return 
		}
		let half = 100/this.data.files.length;
		this.openMask();
		let options = { albumId:this.data.albumId,albumClassId:this.data.albumClassId, userId:this.data.userId }
		this.data.files.filter(async item => {
			await uploadImg(item,options).then(res => {
				this.setData({
					width: this.data.width+half,
					count: this.data.count +1,
          successCount: this.data.successCount+1
				})
			}).catch(()=>{
        this.setData({
          failCount:this.data.failCount+1,
          width: this.data.width + half,
          count: this.data.count + 1
        })
      })
      if (this.data.count == this.data.files.length) {
        setTimeout(() => {
          this.setData({
            carryOut: true,
            width: 0,
            count: 0
          })
          wx.setStorage({
            key: "上传",
            data: { msg: '上传成功' }
          })
        }, 1000)
        return
      }
		})
	},
	//打开车罩层
	openMask: function(){
		this.setData({
			mask: !this.data.mask
		})
	},
	previewImg: function(e){
		wx.previewImage({
		  current: e.currentTarget.dataset.item,
		  urls: this.data.files
		})
	},
	colseMask: function(){
		if(this.data.carryOut){
			wx.navigateBack();
		}
	}
})