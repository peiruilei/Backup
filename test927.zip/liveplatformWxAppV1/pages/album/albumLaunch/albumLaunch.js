//index.js
//获取应用实例
const app = getApp();
import *as Api from '../../../http/api.js'
Page({
  data: {
    imageStatus: 'normal',
    timeCount: 5,
    timeController: null,
    potoStart: {},
    albumId: 188,
    albumStyle: {}
  },
  onLoad: function(options) {
    var that = this;
    //判断小程序扫码进入的相册id
    if (options.scene !== '' && options.scene !== undefined && options.scene !== null) {
      var scene = decodeURIComponent(options.scene);
      that.setData({
        albumId: scene
      })
    }
    //判断APP扫码进入的相册id
    if (options.albumId !== '' && options.albumId !== undefined && options.albumId !== null) {
      var albumId = decodeURIComponent(options.albumId);
      that.setData({
        albumId: albumId
      })
    }
    app.getUserInfo(this.data.albumId)
    this.bannerPage();
    this.getalbumStyle();
  },
  bannerPage: function() {
    Api.albumLaunchBanner({
      'photoId': this.data.albumId
    }).then(res => {
      this.setData({
        potoStart: res.result
      })
      wx.setNavigationBarTitle({
        title: res.result.photoTopSettings.topCopy
      })
    })
  },
  imageLoaded: function() {
    this.startRender()
  },
  startRender: function() {
    this.setData({
      imageStatus: 'active'
    })
    this.startTimeController()
  },
  startTimeController: function() {
    this.timeController = setInterval(() => {
      this.setData({
        timeCount: this.data.timeCount - 1
      })
      if (this.data.timeCount === 0) {
        clearInterval(this.timeController)
        this.openDetail()
      }
    }, 1000)
  },
  openDetail: function() {
    wx.redirectTo({
      url: `../album/album?albumId=${this.data.albumId}&albumStyle=${JSON.stringify(this.data.albumStyle)}`,
    })
  },
  userClickEnterDetail: function() {
    clearInterval(this.timeController)
    this.openDetail()
  },
  //获取相册风格
  getalbumStyle: function() {
    Api.albumLaunchStyle({ 
      photoAlbumId: this.data.albumId 
    }).then(res => {
      this.setData({
        albumStyle: res.result
      })
    })
  }
})