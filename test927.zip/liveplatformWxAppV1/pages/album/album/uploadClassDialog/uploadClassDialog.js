Component({
	properties:{
		classsettings:{
			type: Array,
			value: []
		}
	},
	data:{
	albumClassId:''  ,//分类id,
    checked: '/static/icons/ic_album_upload_class_checked.png',
    unchecked: '/static/icons/ic_album_upload_class_unchecked.png'
	},
	methods:{
		//选中分类的ID
		selectAlbumClassId: function(e){
			this.setData({
				albumClassId: e.currentTarget.dataset.id
			})
		},
		//点击的确定还是取消
		onButtonClick: function(e){
			let determine = e.currentTarget.dataset.id; 
			if(determine){//确定
				if(!this.data.albumClassId){
					return wx.showToast({
					  title: '请选择分类',
					  icon: 'none',
					  duration: 2000
					})
				}
				this.triggerEvent('isDetermine',this.data.albumClassId)
			}else{//取消
				this.triggerEvent('isDetermine')
			}
		}
	}
})