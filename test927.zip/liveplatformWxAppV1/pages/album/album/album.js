//index.js
//获取应用实例
const app = getApp()
import *as Api from '../../../http/api.js'
Page({
  data: {
    background: '#ffffff', //整个主题的背景色
    topBgImage: '', //顶部的背景图
    topFontColor: '#151515', //顶部文字的颜色
    topNumColor: '#f76958', //顶部的浏览人数字体颜色
    timeIcon: "https://picture-live.oss-cn-beijing.aliyuncs.com/default_diagram/style/ic_album_shoot_time.png", //顶部的时间图标
    siteIcon: "https://picture-live.oss-cn-beijing.aliyuncs.com/default_diagram/style/ic_album_city.png", //顶部的城市图标
    primaryTitleColor: '#151515', //一级标题的文字颜色
    indicatesColor: '#f76958', //一级标题选中后指示条颜色
    stbcClickNormal: '#151515', //二级分类的字体颜色
    stbcClickPressed: '#F86958', //二级分类点击后的颜色
    extendIcon: "https://picture-live.oss-cn-beijing.aliyuncs.com/default_diagram/style/ic_album_extend.png", //侧边延伸的图片
    homeIcon: "https://picture-live.oss-cn-beijing.aliyuncs.com/default_diagram/style/ic_album_home.png", //侧边主页的图片
    reverseIcon: "https://picture-live.oss-cn-beijing.aliyuncs.com/default_diagram/style/ic_album_reverse.png", //侧边逆序的图片
    upload: '', //侧边上传的图片
    shareIcon: '', //侧边分享的图片
    myIcon: '', //侧边我的的图片
    posteIcon: '', //侧边海报的图片
    bottomTitleColor: '#B5B5B5', //底部标题的文字颜色
    bottomContentColor: '#B5B5B5', //底部内容的文字颜色
    backgroundImage: "https://picture-live.oss-cn-beijing.aliyuncs.com/default_diagram/style/ic_album_null.png", //底部没有内容是时显示
    bibFontColor: '#B5B5B5', //底部没有内容时提示颜色
    loadMoreColor: '#B5B5B5',//底部加载更多字体颜色
    homeButtonColor: 'rgba(248, 105, 88, 1)',   //前往主页颜色

    // <====================   上面是控制主题的变量   ======================>
    albumSetId: '', //相册集ID
    title: '',  //标题
    showLogo: false, // logo 控制器
    showLogoTimeController: null, //  计时器时间句柄
    imgShowType: 'two-type', // 图片显示类型
    contentShowIndex: 0, // 盒子显示的索引
    showAppendDetail: false,
    showBottomSheet: false,
    showProgress: false,
    showADDialog: false,
    fister: true, //是否第一次加载
    albumId: 0, //相册id
    phototopsettings: {}, //顶部宣传设置
    result: {}, //相册列表
    zhibo: true, //图片直播
    video: false,
    flag: false,
	  isUpload: false, //上传图片
    classsettings: [], //分类
    defaultsettings: {}, //默认设置
    classIndex: 0, //图片分类下标
    advertisingsettings: {}, //自定义广告设置
    pageNum: 1, //当前页数
    pageSize: 50, //每页显示的数量
    pageVideoNum: 0,
    pageVideoSize: 30, //每页显示的数量
    isHidden: false,
    classId: 0, //分类的classID
    order: 2, //图片逆序/正序
    sort: 2, //视频正序/逆序
    list: [], //相册列表
    wxCard: '', //二维码
    text: '数据加载中，请稍后',
    isShow: false,
    selectListByDate: [], //时间轴的相册图片
    buttonFunction: 0, //按钮状态
    callPhone: '', //拨打电话
    selectAllByVideo: [],
    currentId: 0,
    // 展开折叠
    selectedFlag: false,
    index: 0,
    homeList: [],
    homeObj: {},
    footerObj: {},
    isNull: false,
    showPage: 0,
    hasUserInfo: true,
    scrollTop: "",
    scrollTopClass: '',
    imgClass: [{
      id: 1,
      title: '图片直播'
    }],
    currentIndex: 0,
    scrollH: 0,
    imgWidth: 0,
    loadingCount: 0,
    sharesettings: {} ,//分享设置
	  showUpload: false   ,//是否展示上传,
	  firstLogin: null   ,//是否第一次
    preview: false    ,//预览
    current: 3     //预览的下标
  }, 
  //图片直播、视频按钮
  into: function(e) {
    var that = this
    var id = e.currentTarget.dataset.id
    that.setData({
      currentIndex: id
    })
    if (id == 0) {
      this.setData({
        zhibo: true,
        video: false,
      })
    } else {
      that.setData({
        zhibo: false,
        video: true,
      })
      that.selectAllByPhoto()
    }

  },
  onLoad: function(options) {
    this.setData({
      albumId: options.albumId ,
      firstLogin: app.globalData.firstLogin
    })
    setTimeout(() => {
      this.setData({
        showLogo: true,
        active: true
      })
      this.openADDialog()
    }, 400)
    this.pictureTop()
    this.increaseTraffic()
    //设置主题配置
    this.settingAlbumStyle(JSON.parse(options.albumStyle));
  },
  pictureTop: function() {
    var that = this;
    let url = '/decentralization/pc/selectAnAlbum/selectPictureTopByPhotoId'
    let data = {
      'photoId': that.data.albumId
    }
    let header = {
      'content-type': 'application/json'
    }
    app.appRequest('GET', url, data, header, (res) => {
      if (res.code == 200) {
        if (this.data.fister) {
          this.setData({
            classId: res.result.classsettings[0].id,
            imgClass: res.result.flag ? this.imgClass : [{
              id: 1,
              title: '图片直播'
            }],
          })
        }
        that.setData({
          phototopsettings: res.result.phototopsettings,
          result: res.result,
          classsettings: res.result.classsettings,
          defaultsettings: res.result.defaultsettings,
          sharesettings: res.result.sharesettings,
          advertisingsettings: res.result.advertisingsettings,
          buttonFunction: res.result.advertisingsettings.buttonFunction,
          callPhone: res.result.advertisingsettings.callPhone,
          footerObj: res.result.endingadvertising,
          wxCard: res.result.photoOrcode,
          showUpload: res.result.isUpload,
          title: res.result.photoName
        })
        wx.setNavigationBarTitle({
          title: res.result.phototopsettings.topCopy
        })
        if (that.data.defaultsettings.desplaymode == 1) {
          that.setData({
            contentShowIndex: 1,
            imgShowType: 'normal'
          })
        } else if (that.data.defaultsettings.desplaymode == 2) {
          that.setData({
            contentShowIndex: 2,
            imgShowType: 'two-type'
          })
        } else if (that.data.defaultsettings.desplaymode == 3) {
          that.setData({
            contentShowIndex: 0,
          })
        }
        this.PictureList()
      }
    }, (err) => {
      console.log('请求错误信息：  ' + err.errMsg);
    })
    wx.stopPullDownRefresh(); //停止下拉刷新
  },
  //点击获取相对于分类
  classSettings: function(e) {
    this.data.showPage = 0;
    this.setData({
      classIndex: e.target.dataset.index,
      classId: e.target.dataset.id,
      order: 2,
      pageNum: 1,
      list: []
    })
    if (this.data.classIndex == e.target.dataset.index) {
      this.PictureList();
    }
  },
  //下拉刷新
  onPullDownRefresh: function() {
    var that = this
    that.setData({
      pageNum: 1,
      order: 2,
      fister: false,
      list: [],
      sort: 2,
      selectAllByVideo: [],
      pageVideoNum: 0
    })
    // that.data.classsettings = []
    this.pictureTop()
    this.selectAllByPhoto()
  },
  //上拉加载更多
  onReachBottom: function() {
    var that = this
    if (that.data.video === true) {
      that.setData({
        text: '数据加载中，请稍后'
      })

      this.selectAllByPhoto()
    } else if (that.data.contentShowIndex == 1 || that.data.contentShowIndex == 2) {
      that.setData({
        text: '数据加载中，请稍后',
        isShow: true
      })
      that.data.pageNum++
        this.PictureList();
    }
  },
  //相册列表(瀑布流、九宫格)
  PictureList: function() {
    var that = this;
    if (that.data.contentShowIndex == 0) {
      that.selectListByDate()
    } else {
      // that.data.pageNum == 1
      if (that.data.pageNum == 1) {
        that.setData({
          isShow: true,
          text: '数据加载中，请稍后'
        })
      }
      let url = '/decentralization/pc/selectAnAlbum/selectPictureListByClassId'
      let data = {
        pageNum: that.data.pageNum,
        pageSize: that.data.pageSize,
        classId: that.data.classId,
        order: that.data.order,
        photoId: that.data.albumId,
      }
      let header = {
        'content-type': 'application/json'
      }
      app.appRequest('POST', url, data, header, (res) => {
        // console.log(res)
        if (that.data.pageNum > 1) {
          var lists = that.data.list;
          that.setData({
            list: lists.concat(res.result.list),
            pageNum: that.data.pageNum++,
            isShow: true,
            text: '数据加载中，请稍后',
            showPage: that.data.list.length
          })
        } else {
          that.setData({
            list: res.result.list,
            pageNum: that.data.pageNum++,
            isShow: true,
            text: '数据加载中，请稍后'
          })
        }
        if (res.result.list.length == 0 || res.result.list.length < that.data.pageSize) {
          that.setData({
            isShow: true,
            text: '没有更多数据了'
          })
        }
      }, (err) => {
        wx.showToast({
          title: '服务器异常',
          duration: 1500
        })
        console.log('对接失败');
      })
      this.complete()
    }
  },
  complete: function() {
    if (this.data.pageNum >= 1 || this.data.pageVideoNum >= 1) {
      setTimeout(function() {
        wx.hideLoading()
      }, 2000)
    }
  },
  //相册列表(时间轴)
  selectListByDate: function() {
    var that = this
    // let url = '/authorization/selectListByDate'
    let data = {
      classId: that.data.classId,
      order: that.data.order,
      photoId: that.data.albumId
    }
    let header = {
      'content-type': 'application/json'
    }
    app.appRequest('POST', url, data, header, (res) => {
      if (res.code == 200) {
        that.setData({
          selectListByDate: res.result,
          showPage: that.data.selectListByDate.length
        })
        if (res.result.length <= 0) {
          that.setData({
            isNull: true
          })
        } else {
          that.setData({
            isNull: false
          })
        }
      }
    }, (err) => {
      console.log('请求错误信息：  ' + err.errMsg);
    })
  },
  //视频直播接口
  selectAllByPhoto: function() {
    var _self = this
    _self.data.pageVideoNum == 1
    if (_self.data.pageVideoNum == 1) {
      _self.setData({
        text: '加载中...',
        pageVideoNum: this.data.pageVideoNum++
      })
    }
    let url = '/authorization/selectAllByPhoto'
    let data = {
      pageNum: _self.data.pageVideoNum,
      pageSize: _self.data.pageVideoSize,
      photoId: _self.data.albumId,
      sort: _self.data.sort
    }
    let header = {
      'content-type': 'application/json'
    }
    app.appRequest('POST', url, data, header, (e) => {
      var list = []
      if (e.result && e.result.list) {
        list = e.result.list
      }
      if (e.code == 200) {
        if (_self.data.pageVideoNum > 1) {
          var allByVideo = _self.data.selectAllByVideo;
          _self.setData({
            selectAllByVideo: allByVideo.concat(list),
            pageVideoNum: _self.data.pageVideoNum++,
            text: '加载中...'
          })
        } else {
          _self.setData({
            selectAllByVideo: list,
            pageVideoNum: _self.data.pageVideoNum++,
            text: '加载中...'
          })
        }
        if (list.length == 0 || list.length < _self.data.pageVideoSize) {
          _self.setData({
            isHidden: true,
            text: '没有更多数据了'
          })
        }
      } else {
        wx.showToast({
          title: '获取数据失败',
          icon: 'none',
          duration: 1500,
        })
      }
    }, (err) => {
      wx.showToast({
        title: '服务器异常',
        duration: 1500
      })
      console.log('对接失败');
    })
    _self.complete()
  },
  onPageScroll: function(event) {
    this.setData({
      scrollTopClass: event.scrollTop,
      scrollTop: event.scrollTop
    })
    if (this.data.showLogo) {
      this.setData({
        showLogo: false
      })
    } else {
      this.showLogo()
    }
    if (event.scrollTop >= 200) {
      this.setData({
        showProgress: true,
      })
    } else {
      this.setData({
        showProgress: false,
        showPage: 0
      })
    }
  },
  goTop: function(e) { // 一键回到顶部
    if (wx.pageScrollTo) {
      wx.pageScrollTo({
        scrollTop: 0,
        showPage: 0
      })
    } else {
      wx.showModal({
        title: '提示',
        content: '当前微信版本过低，无法使用该功能，请升级到最新微信版本后重试。'
      })
    }
  },
  showLogo: function() {
    clearTimeout(this.data.showLogoTimeController)
    this.data.showLogoTimeController = setTimeout(() => {
      this.setData({
        showLogo: true
      })
    }, 500)
  },
  //  瀑布流、九宫格按钮
  changeShowType: function(event) {
    let target = event.currentTarget
    let data = target.dataset
    this.setData({
      imgShowType: data.type,
      contentShowIndex: parseInt(data.index)
    })
    this.PictureList()
  },
  //  时间轴按钮
  openHistoryLine: function() {
    this.setData({
      contentShowIndex: 0
    })
    this.selectListByDate()
  },
  openAppendBtn: function() {
    this.setData({
      showAppendDetail: !this.data.showAppendDetail
    })
  },
  // 点击主页
  openBottomSheet: function() {

    Api.albumHomeList({
      photoAlbumId: this.data.albumId
    }).then(res => {
      console.log(res)
      this.setData({
        homeList: res.result.photoWxListBos,
        homeObj: res.result.photoSetMainBo,
        albumSetId: res.result.photoSetMainBo.id
      })
    })
    this.setData({
      showBottomSheet: true
    })
  },
  closeSheet: function() {
    this.setData({
      showBottomSheet: false
    })
  },
  closeADDialog: function() {
    this.setData({
      showADDialog: false
    })
  },
  openADDialog: function() {
    this.setData({
      showADDialog: true
    })
  },
  //侧边栏按钮
  actionSheetTap: function(e) {
    var that = this
    var imgSrc = e.currentTarget.dataset.img
    var link = e.currentTarget.dataset.link
    if (that.data.buttonFunction == 1) {
      wx.navigateTo({
        url: '../albumAdPicture/albumAdPicture?imgSrc=' + imgSrc
      })
    } else if (that.data.buttonFunction == 2) {
      wx.navigateTo({
        url: '../../webPage/webPage?link=' + link
      })
    } else if (that.data.buttonFunction == 3) {
      // 提示呼叫号码还是将号码添加到手机通讯录
      wx.showActionSheet({
        itemList: ['呼叫', '复制', '添加手机通讯录'],
        success: function(res) {
          if (res.tapIndex === 0) {
            // 呼叫号码
            wx.makePhoneCall({
              phoneNumber: that.data.callPhone,
            })
          } else if (res.tapIndex == 1) {
            wx.setClipboardData({
              data: that.data.callPhone,
              success: function(res) {}
            })
          } else if (res.tapIndex == 2) {
            // 添加到手机通讯录
            wx.addPhoneContact({
              firstName: 'test', //联系人姓名
              mobilePhoneNumber: that.data.callPhone, //联系人手机号
              success: function(res_addphone) {
                console.log("电话添加联系人返回：", res_addphone)
              }
            })
          }
        }
      })
    }

  },
  //视频播放按钮
  playbtn: function(e) {
    let item = JSON.stringify(e.currentTarget.dataset.item);
    wx.navigateTo({
      url: `/pages/album/albumVideo/albumVideo?item=${item}`
    })
  },
  jieshu: function() {
    this.pausevideo()
  },
  onHide: function() {
    this.pausevideo()
  },
  onShow: function() {
    this.pausevideo()
	wx.getStorage({
		key: '上传',
		success: (res)=> {
			this.onPullDownRefresh();
			wx.removeStorage({key: '上传'})
		}
	})
  },
  pausevideo: function() {
    this.setData({
      "currentId": null
    })
  },
  // 展开折叠选择
  isOpen: function(e) {
    var that = this;
    var idx = e.currentTarget.dataset.index;
    var memberList = that.data.selectListByDate;
    for (let i = 0; i < memberList.length; i++) {
      if (idx == i) {
        memberList[i].hidden = !memberList[i].hidden;
      } else {
        //点击打开，另一个关闭
        // memberList[i].hidden=true;
      }
    }
    this.setData({
      selectListByDate: memberList
    });
    return true;
  },
  downOption: function() {
    this.setData({
      showAppendDetail: false
    })
  },
  //逆序
  reverse: function() {
    let isorder = this.data.order == 2 ? 1 : 2;
    var that = this
    var timeList = that.data.selectListByDate
    var lists = that.data.list
    if (!that.data.currentIndex) { //图片
      that.setData({
        list: [],
        pageNum: 1,
        order: isorder
      })
      for (var i = 0; i < timeList.length; i++) {
        if (timeList[i].hidden || timeList[0].hidden) {
          timeList[0].hidden = !timeList[0].hidden
        }
      }
      this.PictureList();
    } else {
      // console.log('视频直播')
      that.setData({
        selectAllByVideo: [],
        sort: this.data.sort == 1 ? 2 : 1,
        pageNum: 1,
      })
      this.selectAllByPhoto()
    }
    this.setData({
      showAppendDetail: !this.data.showAppendDetail
    })
  },
  //进入详情页(图片预览)
  getToDetail: function(e) {
    let imgList = []
    this.data.list.map(item => {
      imgList.push(item.watermarkPicture)
    })
    wx.previewImage({
      current: e.currentTarget.dataset.item.watermarkPicture,
      urls: imgList,
    })
    // this.setData({
    //   preview: !this.data.preview,
    //   current: e.currentTarget.dataset.index
    // })
  },
  getToBanner: function(e) {
    var id = e.currentTarget.dataset.id
    wx.redirectTo({
      url: `../albumLaunch/albumLaunch?albumId=${id}`,
    })
  },
  onShareAppMessage: function(options) {
    this.setData({
      showAppendDetail: false
    })
    return {
      title: this.data.sharesettings.shareTitle,
      path: `pages/album/albumLaunch/albumLaunch?albumId=${this.data.albumId}`,
      imageUrl: this.data.sharesettings.shareCover
    }
  },
  //增加流量
  increaseTraffic: function() {
    Api.albumAddFlow({ albumId: this.data.albumId })
  },
  //设置主题
  settingAlbumStyle: function(data) {
    this.setData({
      background: data.background,
      backgroundImage: data.backgroundImage,
      bibFontColor: data.bibFontColor,
      bottomContentColor: data.bottomContentColor,
      bottomTitleColor: data.bottomTitleColor,
      extendIcon: data.extendIcon,
      homeIcon: data.homeIcon,
      indicatesColor: data.indicatesColor,
      myIcon: data.myIcon,
      posteIcon: data.posteIcon,
      primaryTitleColor: data.primaryTitleColor,
      reverseIcon: data.reverseIcon,
      shareIcon: data.shareIcon,
      siteIcon: data.siteIcon,
      stbcClickNormal: data.stbcClickNormal,
      stbcClickPressed: data.stbcClickPressed,
      styleMainId: data.styleMainId,
      timeIcon: data.timeIcon,
      topBgImage: data.topBgImage,
      topFontColor: data.topFontColor,
      topNumColor: data.topNumColor,
      upload: data.uploadIcon, 
      myIcon: data.myIcon ,
      loadMoreColor: data.loadMoreColor,
      homeButtonColor: data.homeButtonColor
    })
  },
  //打开上传图片遮罩层
  checkUpload: function(e){
	  if(this.data.firstLogin)return
	  this.setData({isUpload: !this.data.isUpload})
  },
  isDetermine: function(id){
	  this.checkUpload();
	  if(!id.detail){
		  return 
	  }
	  wx.navigateTo({
		  url: `/pages/album/albumUpload/albumUpload?albumId=${this.data.albumId}&albumClassId=${id.detail}`
	  })
  },
  jumpPoster: function(){
    let data = JSON.stringify([this.data.wxCard]);
    wx.navigateTo({ url: `/pages/album/albumPoster/albumPoster?wxCard=${data}&title=${this.data.title}`})
  },
  // 打开授权
  getUserInfo: function(e){
	  if(e.detail.iv){//确定
		  app.login({
			encryptedData:	e.detail.encryptedData,
			iv:	e.detail.iv,
			sessionKey:	app.globalData.sessionkey,
      albumId: this.data.albumId
		  }).then(res => {
        app.globalData.firstLogin = false
        this.setData({ firstLogin: false })
			  this.checkUpload();
		  })
	  }
  },
  //跳往主页面
  jumpalbumSet: function(){
    wx.navigateTo({
      url: `/pages/albumSet/albumSet?albumSetId=${this.data.albumSetId}`,
    })
    this.setData({
      showBottomSheet: false
    })
  }
})