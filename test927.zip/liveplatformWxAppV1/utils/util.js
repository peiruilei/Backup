const formatTime = date => {
  const year = date.getFullYear()
  const month = date.getMonth() + 1
  const day = date.getDate()
  const hour = date.getHours()
  const minute = date.getMinutes()
  const second = date.getSeconds()

  return [year, month, day].map(formatNumber).join('/') + ' ' + [hour, minute, second].map(formatNumber).join(':')
}

const formatNumber = n => {
  n = n.toString()
  return n[1] ? n : '0' + n
}


//调用访问相册
function transferAuth() {
  return new Promise((resolve, reject) => {
    wx.authorize({
      scope: 'scope.writePhotosAlbum',
      success: res => {
        console.log(res)
        resolve(true)
      },
      fail: eorr => {
        console.log(eorr)
        reject(false)
      }
    })
  })
}
//保存图片
function savePhoto(imgPath) {
  wx.showLoading({
    title: '保存中...'
  })
  wx.saveImageToPhotosAlbum({
    filePath: imgPath,
    success: res => {
      wx.hideLoading()
      wx.showToast({
        title: '保存成功!'
      })
    },
    fail: eorr => {
      wx.hideLoading()
      wx.showToast({
        title: '保存失败,稍后在试试....!',
        icon: 'none'
      })
    }
  })
}
//获取用户是否授权访问相册
function accessPhoto() {
  return new Promise((resolve, reject) => {
    wx.getSetting({
      success: res => {
        console.log(res)
        res.authSetting['scope.writePhotosAlbum'] ? resolve(true) : reject(false)
      }
    })
  })
}
//下载网路图片至本地
function downImg(src) {
  return new Promise((resolve, reject) => {
    wx.getImageInfo({
      src: src,
      success: res => {
        resolve(res.path)
      },
      fail: err => {
        console.log(err)
      }
    })
  })
}
//上传图片
function uploadImg(imgUrl,data){
	return new Promise((resolve,reject) => {
		console.log(data)
		wx.uploadFile({
			url: 'https://live.hn1231.com/wx/album/sidebar/uploadPictures',
			filePath: imgUrl,
			name: 'file',
			header: {
				"Content-Type": "multipart/form-data"
			},
			formData:{...data},
			method: 'POST',
			success: (res) => {
				res.statusCode == 200 ? resolve(true) : reject(false)
			},
			fail: (eorr) => {
				reject(false)
			}
		})
	})
}
module.exports = {
  formatTime,
  savePhoto,
  transferAuth,
  accessPhoto,
  downImg,
  uploadImg
}