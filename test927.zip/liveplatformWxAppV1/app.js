//app.js
App({
  onLaunch: function () {

  },
  globalData: {
    userInfo: null,		//用户信息
    firstLogin: false,//是否第一次登陆
    sessionkey: '' 
  },
  
  
  /**
   *获取code
   */
  getUserInfo: function(data) {
    wx.login({
      success: async (res) => {
        if (res.code) {
          await this.login({ code: res.code, albumId: data})
        }
      }
    })
  },
  
  //登陆的封装
  login: function(data){
	 return new Promise((resolve,reject)=> {
		wx.request({
			url: 'https://live.hn1231.com/wx/user/login',
			data: {...data},
			method: 'POST',
			header: {'content-type': 'application/x-www-form-urlencoded'},
			success:(res) => {
        console.log(res)
				if(res.data.result.accessToken){
					// console.log('登录成功')
					wx.setStorage({
					  key:"userInfo",
					  data: res.data.result.userBo
					})
					resolve(true)
				}else{
					// console.log('第一登陆')
          resolve(false)
          wx.setStorageSync('firstLogin', true)
					this.getAuth()
          this.globalData.firstLogin = true
					this.globalData.sessionkey = res.data.result.sessionkey
				}
			}
		 })
	 })
  },
  
  
  
  /**
   * 是否授权
   */
  getAuth: function(){
    wx.getSetting({
      success: (res) => {
        this.globalData.firstLogin = res.authSetting['scope.userInfo']?false:true
      }
    })
  },
  
  /**
   *修改是否第一次登陆的状态
   */
  checkStatus: function(){
    this.globalData.firstLogin = !this.globalData.firstLogin
    console.log(this.globalData.firstLogin)
  },
  
  
  /**

 * methods： 请求方式

 * url: 请求地址

 * data： 要传递的参数

 * callback： 请求成功回调函数

 * errFun： 请求失败回调函数

 */
  appRequest(methods, url, data, header, callback, errFun) {
    wx.request({
      url: 'https://api.hn1231.com' + url,
      method: methods,
      header: header,
      // header: {
      //     'content-type':  'application/json' || 'application/x-www-form-urlencoded'
      // },
      dataType: 'json',
      data: data,
      success: function (res) {
        callback(res.data);
      },
      fail: function (err) {
        errFun(err);
      }

    })
  }
})