import http from './request.js'
const url = 'https://api.hn1231.com'


/*
 *相册集Api
 */
//查询相册集顶部宣传图
export const albumSetBannerImg = (data) => http.GET(`${url}/wx/albumSet/getAlbumPublicityMap`, data)
//获取相册集介绍
export const albumSetIntroduction = (data) => http.GET(`${url}/decentralization/photoSet/selectPotoIntroduceByPhotoSetId`, data)
//获取相册集列表
export const albumSetList = (data) => http.GET(`${url}/wx/selectPhotoAlbum/selectPhotoListByPhotoSetId`, data)
//相册分享
export const albumSetShare = (data) => http.GET(`${url}/decentralization/photoSet/selectPotoSetShareBySetId`, data)


/*
 *相册启动页Api
 */
//相册启动页
export const albumLaunchBanner = (data) => http.GET(`${url}/decentralization/photo/selectPotoStartPageByPhotoId`, data)
//相册皮肤
export const albumLaunchStyle = (data) => http.GET(`${url}/wx/style/selectStyleDetails`, data)



/*
 *相册Api
 */
//前往主页列表
export const albumHomeList = (data) => http.GET(`${url}/wx/selectPhotoAlbum/selectPhotoListByPhotoToSetId`, data)
//相册介绍
export const albumIntroduction = (data) => http.GET(`${url}/decentralization/pc/selectAnAlbum/selectPictureTopByPhotoId`, data)
//增加流量
export const albumAddFlow = (data) => http.POST(`${url}/applet/album/insertAlbumViews`, data)




/*
 *图片预览api
 */
//照片是否被当前用户收藏和关注
export const isCollection = (data) => http.GET(`${url}/decentralization/collection/selectPictureTypeByPidAndUid`, data);
//收藏照片/喜欢照片
export const collection = (data) => http.POST(`${url}/decentralization/collection/collectionPicture`, data)
//取消收藏/取消喜欢
export const recallCollection = (data) => http.POST(`${url}/decentralization/collection/cancelCollectionPicture`, data)