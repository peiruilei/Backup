// pages/orderDetail/orderDetail.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    logoImg:'../../static/LOGO2x.png',
    orderTime:'2019-10-10 14:18:42',
    orderCode:'8754 5421 5487 3548',
    payStyle:'在线支付',
    shopName:'炭火烤肉（路劲大厦店）',
    orderList: [{ img: '', name: '炭火烤肉', price: '￥40', num: 'x1' }, 
    { img: '', name: '炭火烤肉', price: '￥40', num: 'x1'}],
    state:1
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})